import { useState, useEffect, useCallback } from 'react'
import { getAlerts, acknowledgeAlert } from '../api'

function alertTypeLabel(a) {
  const type = (a.type || 'ppe violation').replace(/_/g, ' ')
  if (a.severity === 'critical') return `CRITICAL — ${type}`
  if (a.severity === 'warning')  return `WARNING — ${type}`
  return `INFO — ${type}`
}

function severityClass(a) {
  if (a.severity === 'critical') return 'critical'
  if (a.severity === 'warning')  return 'warning'
  return 'info'
}

function formatTime(ts) {
  if (!ts) return ''
  if (typeof ts === 'string' && ts.includes('IST')) {
    return ts.split(' ').slice(1, 3).join(' ')
  }
  const d = new Date(ts)
  return isNaN(d) ? ts : d.toLocaleTimeString()
}

export default function AlertFeedPage() {
  const [alerts,       setAlerts]       = useState([])
  const [filter,       setFilter]       = useState('all')
  const [loading,      setLoading]      = useState(true)
  const [ackPopup,     setAckPopup]     = useState(null)
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split('T')[0]
  )

  const fetchAlerts = useCallback(() => {
    setLoading(true)
    getAlerts({ limit: 200, date: selectedDate })
      .then(data => { setAlerts(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [selectedDate])

  useEffect(() => { fetchAlerts() }, [fetchAlerts])

  useEffect(() => {
    const id = setInterval(fetchAlerts, 15_000)
    return () => clearInterval(id)
  }, [fetchAlerts])

  const ack = (id, message) => {
    // Optimistic update
    setAlerts(prev => prev.map(a => a._id === id ? { ...a, acknowledged: true } : a))

    // Show popup
    setAckPopup({ id, message })
    setTimeout(() => setAckPopup(null), 3000)

    // Persist to backend
    acknowledgeAlert(id).catch(() => {
      // Roll back on failure
      setAlerts(prev => prev.map(a => a._id === id ? { ...a, acknowledged: false } : a))
      setAckPopup(null)
    })
  }

  const unacked = alerts.filter(a => !a.acknowledged)
  const counts  = {
    critical: unacked.filter(a => a.severity === 'critical').length,
    warning:  unacked.filter(a => a.severity === 'warning').length,
    info:     unacked.filter(a => a.severity !== 'critical' && a.severity !== 'warning').length,
  }

  const visible = filter === 'all'
    ? alerts
    : alerts.filter(a => severityClass(a) === filter)

  return (
    <div className="screen active" id="screen-alerts">

      {/* ── DATE BAR ── */}
      <div className="date-bar">
        <span className="date-bar-label">📅 Viewing alerts for:</span>
        <input
          type="date"
          className="date-picker"
          value={selectedDate}
          onChange={e => setSelectedDate(e.target.value)}
        />
        <span className="date-bar-hint">← change date to filter alerts</span>
      </div>

      {/* ── KPI CARDS ── */}
      <div className="stat-grid">
        <div className="stat-card red">
          <div className="stat-label">CRITICAL OPEN</div>
          <div className="stat-value red">{counts.critical}</div>
        </div>
        <div className="stat-card amber">
          <div className="stat-label">WARNINGS OPEN</div>
          <div className="stat-value amber">{counts.warning}</div>
        </div>
        <div className="stat-card blue">
          <div className="stat-label">INFO OPEN</div>
          <div className="stat-value blue">{counts.info}</div>
        </div>
        <div className="stat-card green">
          <div className="stat-label">RESOLVED TODAY</div>
          <div className="stat-value green">
            {alerts.filter(a => a.acknowledged).length}
          </div>
        </div>
      </div>

      {/* ── ALERTS PANEL ── */}
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">🔔 All Alerts</div>
          <div className="panel-actions">
            {['critical', 'warning', 'info', 'all'].map(f => (
              <button
                key={f}
                className={`topbar-btn alert-filter-btn${filter === f ? ' primary' : ''}`}
                style={{ padding: '4px 10px', fontSize: 11 }}
                onClick={() => setFilter(f)}
              >
                {f === 'all'
                  ? `All Types (${alerts.length})`
                  : `${f.charAt(0).toUpperCase() + f.slice(1)} (${counts[f] ?? 0})`
                }
              </button>
            ))}
            <button
              className="topbar-btn"
              style={{ padding: '4px 10px', fontSize: 11 }}
              onClick={fetchAlerts}
            >
              🔄 Refresh
            </button>
          </div>
        </div>

        <div className="panel-body">
          {loading ? (
            <div className="text-xs text-muted" style={{ padding: '24px 0', textAlign: 'center' }}>
              Loading alerts…
            </div>
          ) : visible.length === 0 ? (
            <div className="text-xs text-muted" style={{ padding: '24px 0', textAlign: 'center' }}>
              No {filter === 'all' ? '' : filter + ' '}alerts for {selectedDate}
            </div>
          ) : (
            <div className="alert-feed">
              {visible.map(a => (
                <div
                  key={a._id}
                  className={`alert-item ${severityClass(a)}`}
                  style={{ opacity: a.acknowledged ? 0.45 : 1 }}
                >
                  <div className="alert-dot" />

                  <div className="alert-content">
                    <div className="alert-type">{alertTypeLabel(a)}</div>
                    <div className="alert-msg">
                      {a.message
                        ? a.message
                        : a.worker_id
                          ? `Worker ${a.worker_id} — PPE violation`
                          : 'PPE violation detected'
                      }
                    </div>
                    <div className="alert-meta">
                      📹 {a.camera}
                      {a.worker_id ? ` · Worker ${a.worker_id}` : ''}
                      {a.snap_id   ? ` · Snap ${a.snap_id.slice(-6)}` : ''}
                      {' · '}
                      {formatTime(a.timestamp)}
                      {a.acknowledged && a.ack_time
                        ? ` · ACK at ${formatTime(a.ack_time)}`
                        : ''
                      }
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {!a.acknowledged ? (
                      <button
                        className="alert-ack"
                        style={{
                          color:       'var(--green-safe)',
                          borderColor: 'rgba(34,197,94,0.3)',
                        }}
                        onClick={() => ack(
                          a._id,
                          a.message || `Worker ${a.worker_id || '?'} PPE violation`
                        )}
                      >
                        ✓ ACK
                      </button>
                    ) : (
                      <button
                        className="alert-ack"
                        disabled
                        style={{ opacity: 0.5 }}
                      >
                        ✓ Done
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── ACK POPUP ── */}
      {ackPopup && (
        <div style={{
          position:     'fixed',
          bottom:       24,
          right:        24,
          background:   'var(--green-safe)',
          color:        '#000',
          padding:      '12px 20px',
          borderRadius: 8,
          fontWeight:   600,
          fontSize:     14,
          zIndex:       9999,
          boxShadow:    '0 4px 20px rgba(0,0,0,0.4)',
          display:      'flex',
          alignItems:   'center',
          gap:          10,
          maxWidth:     400,
        }}>
          <span>✅ Acknowledged</span>
          <span style={{ fontWeight: 400, fontSize: 12 }}>
            {ackPopup.message}
          </span>
          <button
            onClick={() => setAckPopup(null)}
            style={{
              background:  'none',
              border:      'none',
              color:       '#000',
              cursor:      'pointer',
              fontSize:    16,
              fontWeight:  700,
              marginLeft:  8,
              lineHeight:  1,
            }}
          >
            ✕
          </button>
        </div>
      )}

    </div>
  )
}